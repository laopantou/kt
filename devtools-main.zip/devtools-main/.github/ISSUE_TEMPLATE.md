<!--
IMPORTANT: Please use the following link to create a new issue:

  https://new-issue.vuejs.org/?repo=vuejs/vue-devtools

If your issue was not created using the app above, it will be closed immediately.
-->
