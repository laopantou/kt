<template>
  <fieldset>
    <legend>Form section</legend>
    <slot />
  </fieldset>
</template>
