import { AppRecord } from './api'

export interface Context {
  currentTab: string
  currentAppRecord: AppRecord
}
