<template functional>
  <div>
    Hello {{ props.name }}
    <slot />
  </div>
</template>
